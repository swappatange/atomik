WINDOWS 98 FOR WINDOWS 11 - COMPLETE EDITION
=============================================

ONE-CLICK INSTALL
  1. Right-click the zip > Extract All (installing from inside the
     zip window will NOT work - extract first).
  2. In the extracted folder, double-click:

      INSTALL.bat

  That single run applies ALL of it:
    - the Windows 98 theme (wallpaper, colors, window style, desktop
      icons, cursors, Mystify screensaver, event sounds) - installed
      by direct file copy, no themepack double-click needed
    - navy title bars and taskbar accent
    - classic folder, drive, floppy and CD icons across Explorer
    - startup music at sign-in and shutdown music
    - RetroBar: pixel-accurate Windows 95/98 taskbar
    - Open-Shell classic Start menu + Clouds lock screen (one
      Administrator prompt appears during step 3 - approve it;
      declining still installs everything else)

  Run INSTALL.bat as your normal user - do NOT "Run as administrator"
  (that can apply settings to the wrong user profile). The one piece
  that needs elevation asks for it by itself.

MAKING THE SINGLE, FULLY OFFLINE INSTALLER (recommended first step)
  Double-click PREPARE-OFFLINE.bat once on any PC with internet.
  It fetches the two official app installers (RetroBar, Open-Shell)
  into the Installers folder and then packs EVERYTHING into one file:

      Windows98-Complete-OFFLINE.zip

  That single archive is the complete installer - copy it to any
  Windows 11 PC, extract, run INSTALL.bat: no internet, no winget,
  no GitHub is touched at any point. Bundled installers always take
  priority; the network paths only exist as a fallback when the
  Installers folder is empty.

UNINSTALL
  Double-click UNINSTALL.bat - removes the shell layer and the extras
  and returns every setting to the Windows 11 default. Then delete the
  theme tile in Settings > Personalization > Themes if you wish.

PIECE-BY-PIECE (optional)
  Prefer only some parts? Skip INSTALL.bat and use:
    Windows98.themepack             just the theme (double-click)
    Extras\Enable-Win98-Extras.bat  colors + icons + music
    Extras\Install-Win98-Shell.ps1  taskbar + Start menu only

All scripts are short, commented, plain-text PowerShell - read them.
No system files are modified; everything is per-user and reversible.

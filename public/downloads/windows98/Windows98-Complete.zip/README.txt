WINDOWS 98 FOR WINDOWS 11 - COMPLETE EDITION
=============================================

ONE-CLICK INSTALL
  Unzip everything, then double-click:

      INSTALL.bat

  That single run applies ALL of it:
    - the Windows 98 theme (wallpaper, colors, window style, desktop
      icons, cursors, Mystify screensaver, event sounds)
    - navy title bars and taskbar accent
    - classic folder, drive, floppy and CD icons across Explorer
    - startup music at sign-in and shutdown music
    - the Clouds lock screen (when allowed Administrator rights)
    - RetroBar: pixel-accurate Windows 95/98 taskbar (auto-download)
    - Open-Shell: the classic cascading Start menu (auto-download,
      needs the Administrator prompt you'll see at the start)

  Internet is required for the taskbar/Start menu downloads (both are
  free, open-source, fetched from their official GitHub releases).
  Approve the Administrator prompt for the Start menu + lock screen;
  declining it still installs everything else.

UNINSTALL
  Double-click UNINSTALL.bat - removes the shell layer and the extras
  and returns every setting to the Windows 11 default. Then delete the
  theme tile in Settings > Personalization > Themes if you wish.

PIECE-BY-PIECE (optional)
  Prefer only some parts? Skip INSTALL.bat and use:
    Windows98.themepack             just the theme (double-click)
    Extras\Enable-Win98-Extras.bat  colors + icons + music
    Extras\Install-Win98-Shell.ps1  taskbar + Start menu only

All scripts are short, commented, plain-text PowerShell - read them.
No system files are modified; everything is per-user and reversible.

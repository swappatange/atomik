WINDOWS 98 THEME FOR WINDOWS 11
================================

STEP 1 - install the theme (required)
  Double-click Windows98.themepack. Done: wallpaper, colors, window
  style, desktop icons, cursors, screensaver and event sounds all
  apply instantly. Do not rename the file before opening it.

STEP 2 - enable the extras (recommended)
  Windows 11 itself disables logon/logoff music and hides classic
  title bar colors behind per-user settings that theme files are not
  allowed to change. Double-click:

      Extras\Enable-Win98-Extras.bat

  to get: navy title bars & taskbar accent, classic yellow folder
  icons across Explorer, startup music at sign-in, shutdown music,
  and (if run as Administrator) the Clouds lock screen.

UNDO
  Theme:  Settings > Personalization > Themes > pick another theme.
  Extras: double-click Extras\Remove-Win98-Extras.bat.

Everything is per-user and reversible. No system files are modified.

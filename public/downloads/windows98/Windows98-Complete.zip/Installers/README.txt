OPTIONAL - OFFLINE INSTALLERS
==============================
INSTALL.bat installs RetroBar and Open-Shell via winget or their
official GitHub releases. If you prefer a fully offline install
(or those sources are unreachable), download these two files and
place them in THIS folder before running INSTALL.bat:

  RetroBar installer (.msi)
    https://github.com/dremin/RetroBar/releases  (latest release)

  OpenShellSetup_*.exe
    https://github.com/Open-Shell/Open-Shell-Menu/releases

Files placed here are used first, before any download is tried.
